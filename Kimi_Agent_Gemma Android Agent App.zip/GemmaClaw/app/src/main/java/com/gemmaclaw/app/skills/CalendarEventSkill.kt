package com.gemmaclaw.app.skills

import android.content.Context
import android.content.Intent
import android.provider.CalendarContract
import org.json.JSONObject

class CalendarEventSkill : Skill {

    override val name = "create_calendar_event"

    override val description = """
Create a calendar event using the system calendar app.
Args:
{
  "title": "Meeting with team",
  "description": "Discuss roadmap",
  "location": "Office",
  "begin_time": "2025-01-01T10:00:00",
  "end_time": "2025-01-01T11:00:00"
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult {
        val title = args.optString("title", "New Event")
        val description = args.optString("description", "")
        val location = args.optString("location", "")
        val beginTimeStr = args.optString("begin_time", "")
        val endTimeStr = args.optString("end_time", "")

        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.Events.TITLE, title)
            putExtra(CalendarContract.Events.DESCRIPTION, description)
            putExtra(CalendarContract.Events.EVENT_LOCATION, location)

            if (beginTimeStr.isNotBlank()) {
                try {
                    val beginMillis = parseIsoTime(beginTimeStr)
                    putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, beginMillis)
                } catch (_: Exception) { }
            }

            if (endTimeStr.isNotBlank()) {
                try {
                    val endMillis = parseIsoTime(endTimeStr)
                    putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
                } catch (_: Exception) { }
            }

            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            SkillResult.success("Opened calendar to create event: $title")
        } catch (e: Exception) {
            SkillResult.failure("Could not open calendar: ${e.message}")
        }
    }

    private fun parseIsoTime(iso: String): Long {
        // Simple ISO parser fallback
        return try {
            java.time.Instant.parse(iso).toEpochMilli()
        } catch (_: Exception) {
            System.currentTimeMillis()
        }
    }
}
