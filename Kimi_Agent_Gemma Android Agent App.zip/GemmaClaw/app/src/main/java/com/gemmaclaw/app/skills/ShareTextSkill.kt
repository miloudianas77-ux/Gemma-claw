package com.gemmaclaw.app.skills

import android.content.Context
import android.content.Intent
import org.json.JSONObject

class ShareTextSkill : Skill {

    override val name = "share_text"

    override val description = """
Share text with another app using Android share sheet.
Args:
{
  "text": "message to share"
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult {
        val text = args.optString("text")

        if (text.isBlank()) {
            return SkillResult.failure("No text provided")
        }

        return try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }

            val shareIntent = Intent.createChooser(sendIntent, "Share with").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(shareIntent)
            SkillResult.success("Opened share sheet")
        } catch (e: Exception) {
            SkillResult.failure("Could not open share sheet: ${e.message}")
        }
    }
}
