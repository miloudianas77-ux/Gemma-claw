package com.gemmaclaw.app.skills

import android.content.Context
import org.json.JSONObject

interface Skill {
    val name: String
    val description: String

    suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult
}

data class SkillResult(
    val success: Boolean,
    val message: String,
    val data: JSONObject? = null
) {
    companion object {
        fun success(message: String, data: JSONObject? = null) =
            SkillResult(true, message, data)

        fun failure(message: String) =
            SkillResult(false, message)
    }
}
