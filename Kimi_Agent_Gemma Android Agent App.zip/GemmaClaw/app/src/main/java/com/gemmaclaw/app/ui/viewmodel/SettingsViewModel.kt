package com.gemmaclaw.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gemmaclaw.app.GemmaClawApplication
import com.gemmaclaw.app.settings.SettingsRepository
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepo = (application as GemmaClawApplication).settingsRepository

    val modelPath: StateFlow<String> = settingsRepo.modelPath
    val maxTokens: StateFlow<Int> = settingsRepo.maxTokens
    val temperature: StateFlow<Float> = settingsRepo.temperature
    val topK: StateFlow<Int> = settingsRepo.topK
    val memoryEnabled: StateFlow<Boolean> = settingsRepo.memoryEnabled
    val onboardingComplete: StateFlow<Boolean> = settingsRepo.onboardingComplete

    fun updateModelPath(path: String) {
        viewModelScope.launch { settingsRepo.setModelPath(path) }
    }

    fun updateMaxTokens(value: Int) {
        viewModelScope.launch { settingsRepo.setMaxTokens(value) }
    }

    fun updateTemperature(value: Float) {
        viewModelScope.launch { settingsRepo.setTemperature(value) }
    }

    fun updateTopK(value: Int) {
        viewModelScope.launch { settingsRepo.setTopK(value) }
    }

    fun setMemoryEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setMemoryEnabled(enabled) }
    }

    fun setOnboardingComplete(complete: Boolean) {
        viewModelScope.launch { settingsRepo.setOnboardingComplete(complete) }
    }
}
