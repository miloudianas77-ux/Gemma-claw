package com.gemmaclaw.app.skills

import android.content.Context
import com.gemmaclaw.app.memory.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

class ReadNotesSkill(context: Context) : Skill {

    private val noteDao = AppDatabase.getDatabase(context).noteDao()

    override val name = "read_notes"

    override val description = """
Read saved notes from local memory.
Args:
{
  "query": "optional search keyword",
  "limit": 10
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult = withContext(Dispatchers.IO) {
        val query = args.optString("query", "")
        val limit = args.optInt("limit", 10)

        return@withContext try {
            val notes = if (query.isBlank()) {
                noteDao.getRecentNotes(limit)
            } else {
                noteDao.searchNotes("%$query%", limit)
            }

            val notesJson = org.json.JSONArray()
            notes.forEach { note ->
                val obj = org.json.JSONObject().apply {
                    put("id", note.id)
                    put("title", note.title)
                    put("content", note.content)
                    put("timestamp", note.timestamp)
                }
                notesJson.put(obj)
            }

            val data = JSONObject().apply {
                put("notes", notesJson)
                put("count", notes.size)
            }

            val message = if (notes.isEmpty()) {
                "No notes found."
            } else {
                notes.joinToString("\n") { "- ${it.title}: ${it.content.take(100)}" }
            }

            SkillResult.success(message, data)
        } catch (e: Exception) {
            SkillResult.failure("Failed to read notes: ${e.message}")
        }
    }
}
