package com.gemmaclaw.app.llm

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.io.Closeable

private const val TAG = "GemmaEngine"

class GemmaEngine(
    private val context: Context
) : Closeable {

    private var llm: LlmInference? = null
    private var isStreaming = false
    private var streamCallback: ((String, Boolean) -> Unit)? = null

    fun loadModel(
        modelPath: String,
        maxTokens: Int = 2048,
        topK: Int = 40,
        temperature: Float = 0.7f
    ): Boolean {
        close()

        return try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelPath)
                .setMaxTokens(maxTokens)
                .setTopK(topK)
                .setTemperature(temperature)
                .setResultListener { partial, done ->
                    streamCallback?.invoke(partial, done)
                    if (done) {
                        isStreaming = false
                    }
                }
                .build()

            llm = LlmInference.createFromOptions(context, options)
            Log.i(TAG, "Model loaded: $modelPath")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load model: ${e.message}")
            false
        }
    }

    fun isLoaded(): Boolean = llm != null

    fun generate(prompt: String): String {
        val engine = llm ?: error("Model not loaded")
        return try {
            engine.generateResponse(prompt)
        } catch (e: Exception) {
            Log.e(TAG, "Generation error: ${e.message}")
            "Error: ${e.message}"
        }
    }

    fun stream(prompt: String): Flow<String> = callbackFlow {
        val engine = llm ?: run {
            trySend("Error: Model not loaded")
            close()
            return@callbackFlow
        }

        isStreaming = true
        streamCallback = { partial, done ->
            if (!isClosedForSend) {
                trySend(partial)
            }
            if (done && !isClosedForSend) {
                isStreaming = false
                streamCallback = null
                close()
            }
        }

        try {
            engine.generateResponseAsync(prompt)
        } catch (e: Exception) {
            isStreaming = false
            streamCallback = null
            if (!isClosedForSend) {
                trySend("Error: ${e.message}")
                close()
            }
        }

        awaitClose {
            isStreaming = false
            streamCallback = null
        }
    }

    fun stopGeneration() {
        isStreaming = false
    }

    override fun close() {
        try {
            llm?.close()
        } catch (_: Exception) {
            // Ignore close errors
        }
        llm = null
        isStreaming = false
    }
}
