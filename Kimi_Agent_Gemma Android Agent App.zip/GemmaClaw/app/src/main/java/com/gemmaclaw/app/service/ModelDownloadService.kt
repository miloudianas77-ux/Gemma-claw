package com.gemmaclaw.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.gemmaclaw.app.R

class ModelDownloadService : Service() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("GemmaClaw")
            .setContentText("Processing model...")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)

        // Actual download / processing would run in a coroutine here
        // For now, this is a stub that stops after starting

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf(startId)

        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Model Operations",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background model downloads and indexing"
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "gemmaclaw_model_ops"
        private const val NOTIFICATION_ID = 1001
    }
}
