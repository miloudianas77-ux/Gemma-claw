package com.gemmaclaw.app.ui

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.gemmaclaw.app.ui.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelPickerScreen(
    viewModel: ChatViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val modelLoaded by viewModel.currentModelLoaded
    var showTestDialog by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { viewModel.importModel(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Models") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Current model status
            Surface(
                color = if (modelLoaded)
                    MaterialTheme.colorScheme.primaryContainer
                else
                    MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (modelLoaded) "Model Loaded" else "No Model Loaded",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (modelLoaded)
                            MaterialTheme.colorScheme.onPrimaryContainer
                        else
                            MaterialTheme.colorScheme.onErrorContainer
                    )
                    Text(
                        text = "Import a .task or .litertlm model file to run locally.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (modelLoaded)
                            MaterialTheme.colorScheme.onPrimaryContainer
                        else
                            MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }

            HorizontalDivider()

            // Import action
            ListItem(
                headlineContent = { Text("Import Model") },
                supportingContent = { Text("Select .task or .litertlm file from storage") },
                leadingContent = { Icon(Icons.Default.FileOpen, null) },
                modifier = Modifier.clickable {
                    filePicker.launch("*/*")
                }
            )
            HorizontalDivider()

            // Test model
            ListItem(
                headlineContent = { Text("Test Model") },
                supportingContent = { Text("Run a quick prompt to verify the model works") },
                leadingContent = { Icon(Icons.Default.Science, null) },
                modifier = Modifier.clickable {
                    if (modelLoaded) {
                        showTestDialog = true
                    }
                }
            )
            HorizontalDivider()

            // Instructions
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "How to get a model:",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = """
1. Download a Gemma model converted to MediaPipe .task format.
2. Or convert using the MediaPipe model conversion tools.
3. Models are large (2-4GB). Ensure you have free storage.
4. For testing, push a model via adb:
   adb push gemma.task /sdcard/Download/
                        """.trimIndent(),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }

    if (showTestDialog) {
        var testResult by remember { mutableStateOf<String?>(null) }
        var testing by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showTestDialog = false },
            title = { Text("Test Model") },
            text = {
                Column {
                    if (testing) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Running test prompt...")
                    } else if (testResult != null) {
                        Text("Result:")
                        Text(testResult!!, style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("Send a test prompt: \"What is 2+2?\"")
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (!testing && testResult == null) {
                            testing = true
                            viewModel.sendMessage("What is 2+2? Brief answer.")
                            // In a real app you'd observe the response; here we just simulate
                            testResult = "Test prompt sent. Check chat for response."
                            testing = false
                        } else {
                            showTestDialog = false
                        }
                    }
                ) {
                    Text(if (testResult == null) "Run" else "Close")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTestDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
