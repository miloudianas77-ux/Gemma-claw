package com.gemmaclaw.app.skills

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class WebSearchSkill : Skill {

    override val name = "web_search"

    override val description = """
Search the web using DuckDuckGo HTML results (no API key needed).
Args:
{
  "query": "latest Android news"
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult = withContext(Dispatchers.IO) {
        val query = args.optString("query", "")

        if (query.isBlank()) {
            return@withContext SkillResult.failure("Empty search query")
        }

        return@withContext try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = URL("https://html.duckduckgo.com/html/?q=$encoded")

            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.setRequestProperty("User-Agent", "Mozilla/5.0")
            connection.connectTimeout = 15000
            connection.readTimeout = 15000

            val response = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            // Simple extraction of result titles
            val titles = extractTitles(response)
            val summary = titles.take(5).joinToString("\n") { "- $it" }

            val data = JSONObject().apply {
                put("results_count", titles.size)
                put("top_results", org.json.JSONArray(titles.take(5)))
            }

            SkillResult.success("Search results for \"$query\":\n$summary", data)
        } catch (e: Exception) {
            SkillResult.failure("Search failed: ${e.message}")
        }
    }

    private fun extractTitles(html: String): List<String> {
        val regex = Regex("<a\\s+class=\"result__a\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL)
        return regex.findAll(html)
            .map { it.groupValues[1].replace(Regex("<[^>]*>"), "").trim() }
            .filter { it.isNotBlank() }
            .toList()
    }
}
