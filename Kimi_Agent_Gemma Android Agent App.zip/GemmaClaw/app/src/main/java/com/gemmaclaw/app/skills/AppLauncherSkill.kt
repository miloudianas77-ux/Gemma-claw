package com.gemmaclaw.app.skills

import android.content.Context
import android.content.Intent
import org.json.JSONObject

class AppLauncherSkill : Skill {

    override val name = "launch_app"

    override val description = """
Launch an installed app by package name.
Args:
{
  "package": "com.whatsapp"
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult {
        val packageName = args.optString("package")

        if (packageName.isBlank()) {
            return SkillResult.failure("Missing package name")
        }

        return try {
            val pm = context.packageManager
            val launchIntent = pm.getLaunchIntentForPackage(packageName)
                ?: return SkillResult.failure("App not found: $packageName")

            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            SkillResult.success("Launched app: $packageName")
        } catch (e: Exception) {
            SkillResult.failure("Could not launch app: ${e.message}")
        }
    }
}
