package com.gemmaclaw.app.skills

import android.content.Context
import org.json.JSONObject

class RewriteTextSkill : Skill {

    override val name = "rewrite_text"

    override val description = """
Request the model to rewrite or rephrase text.
Args:
{
  "text": "Original text",
  "style": "formal | casual | concise | professional"
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult {
        val text = args.optString("text", "")
        val style = args.optString("style", "concise")

        if (text.isBlank()) {
            return SkillResult.failure("No text provided")
        }

        val data = JSONObject().apply {
            put("requested_style", style)
            put("original_length", text.length)
        }

        return SkillResult.success(
            "Rewrite the following text in a $style style:\n\n$text",
            data
        )
    }
}
