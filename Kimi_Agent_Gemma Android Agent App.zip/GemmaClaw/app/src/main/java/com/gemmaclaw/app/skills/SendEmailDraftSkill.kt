package com.gemmaclaw.app.skills

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject

class SendEmailDraftSkill : Skill {

    override val name = "send_email_draft"

    override val description = """
Open the email app with a pre-filled draft (user must confirm and send).
Args:
{
  "to": "friend@example.com",
  "subject": "Hello",
  "body": "Email body text"
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult {
        val to = args.optString("to", "")
        val subject = args.optString("subject", "")
        val body = args.optString("body", "")

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            putExtra(Intent.EXTRA_EMAIL, if (to.isNotBlank()) arrayOf(to) else null)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            SkillResult.success("Opened email draft. Please review and send.")
        } catch (e: Exception) {
            SkillResult.failure("Could not open email app: ${e.message}")
        }
    }
}
