package com.gemmaclaw.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.gemmaclaw.app.ui.ChatScreen
import com.gemmaclaw.app.ui.HyperOSScreen
import com.gemmaclaw.app.ui.ModelPickerScreen
import com.gemmaclaw.app.ui.SettingsScreen
import com.gemmaclaw.app.ui.theme.GemmaClawTheme
import com.gemmaclaw.app.ui.viewmodel.ChatViewModel
import com.gemmaclaw.app.ui.viewmodel.SettingsViewModel

class MainActivity : ComponentActivity() {

    private val chatViewModel: ChatViewModel by viewModels()
    private val settingsViewModel: SettingsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            GemmaClawTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()

                    NavHost(
                        navController = navController,
                        startDestination = "chat"
                    ) {
                        composable("chat") {
                            ChatScreen(
                                viewModel = chatViewModel,
                                onNavigateToSettings = {
                                    navController.navigate("settings")
                                }
                            )
                        }
                        composable("settings") {
                            SettingsScreen(
                                viewModel = settingsViewModel,
                                onNavigateBack = {
                                    navController.popBackStack()
                                },
                                onNavigateToModels = {
                                    navController.navigate("models")
                                },
                                onNavigateToHyperOS = {
                                    navController.navigate("hyperos")
                                }
                            )
                        }
                        composable("models") {
                            ModelPickerScreen(
                                viewModel = chatViewModel,
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        }
                        composable("hyperos") {
                            HyperOSScreen(
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
