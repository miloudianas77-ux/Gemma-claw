package com.gemmaclaw.app.skills

import android.content.Context
import com.gemmaclaw.app.memory.AppDatabase
import com.gemmaclaw.app.memory.NoteEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

class NotesSkill(context: Context) : Skill {

    private val noteDao = AppDatabase.getDatabase(context).noteDao()

    override val name = "save_note"

    override val description = """
Save a local note/memory to the device's database.
Args:
{
  "title": "note title",
  "content": "note content"
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult = withContext(Dispatchers.IO) {
        val title = args.optString("title", "Untitled")
        val content = args.optString("content")

        if (content.isBlank()) {
            return@withContext SkillResult.failure("Empty note content")
        }

        return@withContext try {
            val note = NoteEntity(
                title = title,
                content = content,
                timestamp = System.currentTimeMillis()
            )
            noteDao.insert(note)
            SkillResult.success("Saved note: $title")
        } catch (e: Exception) {
            SkillResult.failure("Failed to save note: ${e.message}")
        }
    }
}
