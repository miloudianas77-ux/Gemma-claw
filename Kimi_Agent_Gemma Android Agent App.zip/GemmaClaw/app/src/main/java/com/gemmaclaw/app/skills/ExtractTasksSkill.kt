package com.gemmaclaw.app.skills

import android.content.Context
import org.json.JSONObject

class ExtractTasksSkill : Skill {

    override val name = "extract_tasks"

    override val description = """
Request the model to extract actionable tasks from text.
Args:
{
  "text": "Meeting notes or message containing tasks"
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult {
        val text = args.optString("text", "")

        if (text.isBlank()) {
            return SkillResult.failure("No text provided")
        }

        val data = JSONObject().apply {
            put("source_length", text.length)
        }

        return SkillResult.success(
            "Extract a list of actionable tasks from the following text:\n\n$text",
            data
        )
    }
}
