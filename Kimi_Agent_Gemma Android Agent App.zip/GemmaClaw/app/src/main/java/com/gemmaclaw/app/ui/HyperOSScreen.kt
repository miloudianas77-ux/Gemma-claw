package com.gemmaclaw.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HyperOSScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("HyperOS Optimization") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "For Xiaomi / POCO / Redmi devices running HyperOS",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            }

            val tips = listOf(
                Pair("Battery Saver → No restrictions", "Settings → Apps → GemmaClaw → Battery Saver → No restrictions"),
                Pair("Enable Autostart", "Settings → Apps → Permissions → Autostart → Enable GemmaClaw"),
                Pair("Lock app in Recents", "Open Recents → Long press GemmaClaw → Lock"),
                Pair("Allow Notifications", "Settings → Apps → GemmaClaw → Notifications → Allow all"),
                Pair("Allow Exact Alarms", "Settings → Apps → GemmaClaw → Alarms & reminders → Allow"),
                Pair("Disable Memory Extension Restrictions", "Settings → Battery → App battery saver → GemmaClaw → No restrictions")
            )

            tips.forEach { (title, desc) ->
                ListItem(
                    headlineContent = { Text(title) },
                    supportingContent = { Text(desc) },
                    leadingContent = { Icon(Icons.Default.CheckCircle, null) }
                )
                HorizontalDivider()
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.parse("package:${context.packageName}")
                    }
                    context.startActivity(intent)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Icon(Icons.Default.OpenInNew, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Open App Settings")
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = {
                    val intent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
                    context.startActivity(intent)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Icon(Icons.Default.BatterySaver, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Open Battery Settings")
            }
        }
    }
}
