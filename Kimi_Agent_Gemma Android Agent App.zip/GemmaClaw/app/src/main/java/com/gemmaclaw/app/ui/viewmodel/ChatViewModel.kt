package com.gemmaclaw.app.ui.viewmodel

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gemmaclaw.app.GemmaClawApplication
import com.gemmaclaw.app.llm.AgentLoop
import com.gemmaclaw.app.llm.GemmaEngine
import com.gemmaclaw.app.llm.PromptBuilder.ChatMessage
import com.gemmaclaw.app.memory.MemoryRepository
import com.gemmaclaw.app.settings.SettingsRepository
import com.gemmaclaw.app.skills.SkillRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val TAG = "ChatViewModel"

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as GemmaClawApplication
    private val settingsRepo = app.settingsRepository

    private val _gemmaEngine = GemmaEngine(application)
    private val _skillRegistry by lazy { SkillRegistry.createDefault(application) }
    private val _agentLoop by lazy {
        AgentLoop(
            application,
            _gemmaEngine,
            _skillRegistry,
            if (settingsRepo.memoryEnabled.value) memoryRepo else null
        )
    }

    private val memoryRepo by lazy { MemoryRepository(app.database) }

    private val _messages = MutableStateFlow<List<ChatUiMessage>>(emptyList())
    val messages: StateFlow<List<ChatUiMessage>> = _messages

    val isGenerating = mutableStateOf(false)
    val currentModelLoaded = mutableStateOf(false)
    val offlineMode = mutableStateOf(true)

    init {
        viewModelScope.launch {
            loadModelFromSettings()
            loadChatHistory()
        }
    }

    private suspend fun loadModelFromSettings() {
        val path = settingsRepo.modelPath.value
        if (path.isNotBlank()) {
            val maxTokens = settingsRepo.maxTokens.value
            val temp = settingsRepo.temperature.value
            val topK = settingsRepo.topK.value
            val success = withContext(Dispatchers.Default) {
                _gemmaEngine.loadModel(path, maxTokens, topK, temp)
            }
            currentModelLoaded.value = success
            Log.i(TAG, "Model load result: $success for path $path")
        }
    }

    private suspend fun loadChatHistory() {
        if (settingsRepo.memoryEnabled.value) {
            val history = memoryRepo.getChatHistory(100)
            val uiMessages = history.map {
                ChatUiMessage(
                    content = it.content,
                    isUser = it.isUser,
                    timestamp = it.timestamp,
                    isToolResult = false
                )
            }
            _messages.value = uiMessages
        }
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        if (!_gemmaEngine.isLoaded()) {
            addMessage(ChatUiMessage("No model loaded. Import a model in Settings.", isUser = false))
            return
        }

        viewModelScope.launch {
            // Add user message
            val userMsg = ChatUiMessage(text, isUser = true)
            addMessage(userMsg)
            saveToMemory(text, isUser = true)

            isGenerating.value = true

            val chatHistory = _messages.value.map {
                ChatMessage(it.content, it.isUser, it.timestamp)
            }

            try {
                val response = _agentLoop.respond(text, chatHistory, useStreaming = false)

                when (response) {
                    is AgentLoop.AgentResponse.Text -> {
                        val assistantMsg = ChatUiMessage(response.content, isUser = false)
                        addMessage(assistantMsg)
                        saveToMemory(response.content, isUser = false)
                    }
                    is AgentLoop.AgentResponse.Error -> {
                        addMessage(ChatUiMessage("Error: ${response.message}", isUser = false))
                    }
                    is AgentLoop.AgentResponse.Stream -> {
                        // Handle streaming if needed; for now collect
                        val builder = StringBuilder()
                        response.flow.collect { partial ->
                            builder.append(partial)
                        }
                        val content = builder.toString()
                        addMessage(ChatUiMessage(content, isUser = false))
                        saveToMemory(content, isUser = false)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error during generation", e)
                addMessage(ChatUiMessage("Error: ${e.message}", isUser = false))
            } finally {
                isGenerating.value = false
            }
        }
    }

    fun stopGeneration() {
        _gemmaEngine.stopGeneration()
        isGenerating.value = false
    }

    fun clearChat() {
        _messages.value = emptyList()
        viewModelScope.launch {
            memoryRepo.clearChatHistory()
        }
    }

    fun loadModel(path: String, maxTokens: Int = 2048, topK: Int = 40, temperature: Float = 0.7f) {
        viewModelScope.launch(Dispatchers.Default) {
            val success = _gemmaEngine.loadModel(path, maxTokens, topK, temperature)
            currentModelLoaded.value = success
            if (success) {
                settingsRepo.setModelPath(path)
            }
        }
    }

    fun importModel(uri: Uri) {
        // Copy file to app-private storage and load
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val inputStream = getApplication<Application>().contentResolver.openInputStream(uri)
                    ?: return@launch
                val fileName = uri.lastPathSegment ?: "imported_model.task"
                val destFile = java.io.File(getApplication<Application>().filesDir, "models/$fileName")
                destFile.parentFile?.mkdirs()

                inputStream.use { input ->
                    destFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }

                loadModel(destFile.absolutePath)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to import model", e)
            }
        }
    }

    private fun addMessage(msg: ChatUiMessage) {
        _messages.value = _messages.value + msg
    }

    private fun saveToMemory(content: String, isUser: Boolean) {
        viewModelScope.launch {
            if (settingsRepo.memoryEnabled.value) {
                memoryRepo.saveMessage(content, isUser)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        _gemmaEngine.close()
    }

    data class ChatUiMessage(
        val content: String,
        val isUser: Boolean,
        val timestamp: Long = System.currentTimeMillis(),
        val isToolResult: Boolean = false
    )
}
