package com.gemmaclaw.app.skills

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import com.gemmaclaw.app.receiver.ReminderReceiver
import org.json.JSONObject

class ReminderSkill : Skill {

    override val name = "create_reminder"

    override val description = """
Create a system reminder/alarm.
Args:
{
  "title": "Take medicine",
  "message": "Take your vitamin D",
  "delay_minutes": 30
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult {
        val title = args.optString("title", "Reminder")
        val message = args.optString("message", "")
        val delayMinutes = args.optInt("delay_minutes", 0)

        if (delayMinutes <= 0) {
            return SkillResult.failure("Please specify delay_minutes > 0")
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        // Check exact alarm permission on Android 12+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!alarmManager.canScheduleExactAlarms()) {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return SkillResult.failure("Please grant exact alarm permission in settings")
            }
        }

        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("title", title)
            putExtra("message", message)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            System.currentTimeMillis().toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val triggerAtMillis = System.currentTimeMillis() + (delayMinutes * 60 * 1000L)

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
            SkillResult.success("Reminder set: \"$title\" in $delayMinutes minutes")
        } catch (e: Exception) {
            SkillResult.failure("Failed to set reminder: ${e.message}")
        }
    }
}
