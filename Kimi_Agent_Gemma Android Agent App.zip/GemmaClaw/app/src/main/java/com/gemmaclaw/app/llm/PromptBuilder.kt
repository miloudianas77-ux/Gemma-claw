package com.gemmaclaw.app.llm

import com.gemmaclaw.app.skills.SkillRegistry

object PromptBuilder {

    fun buildSystemPrompt(enabledTools: String): String {
        return """
You are GemmaClaw, a local Android AI agent running on the user's phone.

You are optimized for Gemma models.
You can chat normally, but when an action is needed, use a tool call.

Rules:
1. Never claim a tool succeeded unless the app confirms it.
2. If you need to use a tool, output ONLY valid JSON.
3. Do not wrap JSON in markdown.
4. Ask permission before sensitive actions.
5. Prefer local/offline tools when possible.
6. Be concise and helpful.

Available tools:
$enabledTools

Tool call format:
{
  "tool": "tool_name",
  "args": {
    "key": "value"
  }
}

If no tool is needed, answer normally.
        """.trimIndent()
    }

    fun buildSystemPromptWithMemory(
        enabledTools: String,
        memories: List<String>
    ): String {
        val memorySection = if (memories.isNotEmpty()) {
            "\n\nUser Memories:\n" + memories.joinToString("\n") { "- $it" }
        } else ""

        return buildSystemPrompt(enabledTools) + memorySection
    }

    fun formatChatHistory(messages: List<ChatMessage>): String {
        return messages.joinToString("\n\n") { msg ->
            val role = if (msg.isUser) "User" else "Assistant"
            "$role:\n${msg.content}"
        }
    }

    fun buildPrompt(
        systemPrompt: String,
        chatHistory: String,
        userMessage: String
    ): String {
        return """
$systemPrompt

Conversation:
$chatHistory

User:
$userMessage

Assistant:
        """.trimIndent()
    }

    fun buildFollowUpPrompt(
        systemPrompt: String,
        chatHistory: String,
        userMessage: String,
        toolCall: String,
        toolResult: String
    ): String {
        return """
$systemPrompt

Conversation:
$chatHistory

User:
$userMessage

Assistant requested tool:
$toolCall

Tool result:
$toolResult

Now answer the user naturally.
Assistant:
        """.trimIndent()
    }

    data class ChatMessage(
        val content: String,
        val isUser: Boolean,
        val timestamp: Long = System.currentTimeMillis()
    )
}
