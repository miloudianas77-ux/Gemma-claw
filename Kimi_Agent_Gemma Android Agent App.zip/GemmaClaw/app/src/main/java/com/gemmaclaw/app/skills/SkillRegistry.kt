package com.gemmaclaw.app.skills

import android.content.Context
import org.json.JSONObject

class SkillRegistry(
    private val skills: List<Skill>
) {
    fun get(name: String): Skill? {
        return skills.firstOrNull { it.name == name }
    }

    fun manifest(): String {
        return skills.joinToString("\n") {
            "- ${it.name}: ${it.description}"
        }
    }

    fun listAll(): List<Skill> = skills

    companion object {
        fun createDefault(context: Context): SkillRegistry {
            return SkillRegistry(
                listOf(
                    OpenUrlSkill(),
                    ShareTextSkill(),
                    AppLauncherSkill(),
                    NotesSkill(context),
                    ReadNotesSkill(context),
                    ReminderSkill(),
                    CalendarEventSkill(),
                    OpenMapSkill(),
                    WebSearchSkill(),
                    SummarizeTextSkill(),
                    RewriteTextSkill(),
                    ExtractTasksSkill(),
                    SendEmailDraftSkill()
                )
            )
        }
    }
}
