package com.gemmaclaw.app.skills

import android.content.Context
import org.json.JSONObject

class SummarizeTextSkill : Skill {

    override val name = "summarize_text"

    override val description = """
Request the model to summarize provided text.
Args:
{
  "text": "Long article or content to summarize"
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult {
        val text = args.optString("text", "")

        if (text.isBlank()) {
            return SkillResult.failure("No text provided to summarize")
        }

        // This skill is a no-op pass-through; the model handles summarization in follow-up
        val data = JSONObject().apply {
            put("word_count", text.split(" ").size)
        }

        return SkillResult.success(
            "Text received (${text.length} chars). Summarize it in the follow-up response.",
            data
        )
    }
}
