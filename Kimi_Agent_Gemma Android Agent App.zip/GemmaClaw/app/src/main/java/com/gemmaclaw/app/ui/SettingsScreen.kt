package com.gemmaclaw.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gemmaclaw.app.ui.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToModels: () -> Unit,
    onNavigateToHyperOS: () -> Unit
) {
    val context = LocalContext.current
    val modelPath by viewModel.modelPath.collectAsStateWithLifecycle()
    val maxTokens by viewModel.maxTokens.collectAsStateWithLifecycle()
    val temperature by viewModel.temperature.collectAsStateWithLifecycle()
    val topK by viewModel.topK.collectAsStateWithLifecycle()
    val memoryEnabled by viewModel.memoryEnabled.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            ListItem(
                headlineContent = { Text("Model") },
                supportingContent = {
                    Text(
                        if (modelPath.isNotBlank()) modelPath.substringAfterLast("/")
                        else "No model loaded"
                    )
                },
                leadingContent = { Icon(Icons.Default.Storage, null) },
                trailingContent = { Icon(Icons.Default.ChevronRight, null) },
                modifier = Modifier.clickable { onNavigateToModels() }
            )
            HorizontalDivider()

            ListItem(
                headlineContent = { Text("Max Tokens") },
                supportingContent = { Text("$maxTokens") },
                leadingContent = { Icon(Icons.Default.FormatSize, null) },
                trailingContent = {
                    var showDialog by remember { mutableStateOf(false) }
                    TextButton(onClick = { showDialog = true }) {
                        Text("Edit")
                    }
                    if (showDialog) {
                        NumberPickerDialog(
                            title = "Max Tokens",
                            value = maxTokens,
                            range = 256..4096,
                            onDismiss = { showDialog = false },
                            onConfirm = { viewModel.updateMaxTokens(it) }
                        )
                    }
                }
            )
            HorizontalDivider()

            ListItem(
                headlineContent = { Text("Temperature") },
                supportingContent = { Text("%.1f".format(temperature)) },
                leadingContent = { Icon(Icons.Default.Thermostat, null) },
                trailingContent = {
                    var showDialog by remember { mutableStateOf(false) }
                    TextButton(onClick = { showDialog = true }) {
                        Text("Edit")
                    }
                    if (showDialog) {
                        FloatPickerDialog(
                            title = "Temperature",
                            value = temperature,
                            range = 0.1f..1.5f,
                            onDismiss = { showDialog = false },
                            onConfirm = { viewModel.updateTemperature(it) }
                        )
                    }
                }
            )
            HorizontalDivider()

            ListItem(
                headlineContent = { Text("Top K") },
                supportingContent = { Text("$topK") },
                leadingContent = { Icon(Icons.Default.FilterList, null) },
                trailingContent = {
                    var showDialog by remember { mutableStateOf(false) }
                    TextButton(onClick = { showDialog = true }) {
                        Text("Edit")
                    }
                    if (showDialog) {
                        NumberPickerDialog(
                            title = "Top K",
                            value = topK,
                            range = 1..100,
                            onDismiss = { showDialog = false },
                            onConfirm = { viewModel.updateTopK(it) }
                        )
                    }
                }
            )
            HorizontalDivider()

            ListItem(
                headlineContent = { Text("Memory") },
                supportingContent = { Text("Save conversations and notes locally") },
                leadingContent = { Icon(Icons.Default.Memory, null) },
                trailingContent = {
                    Switch(
                        checked = memoryEnabled,
                        onCheckedChange = { viewModel.setMemoryEnabled(it) }
                    )
                }
            )
            HorizontalDivider()

            ListItem(
                headlineContent = { Text("HyperOS Optimization") },
                supportingContent = { Text("Tips for Xiaomi / POCO / Redmi devices") },
                leadingContent = { Icon(Icons.Default.PhoneAndroid, null) },
                trailingContent = { Icon(Icons.Default.ChevronRight, null) },
                modifier = Modifier.clickable { onNavigateToHyperOS() }
            )
            HorizontalDivider()

            ListItem(
                headlineContent = { Text("Accessibility Service") },
                supportingContent = { Text("Enable for assistive automation (experimental)") },
                leadingContent = { Icon(Icons.Default.Accessibility, null) },
                trailingContent = {
                    TextButton(onClick = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        context.startActivity(intent)
                    }) {
                        Text("Open Settings")
                    }
                }
            )
            HorizontalDivider()

            ListItem(
                headlineContent = { Text("About") },
                supportingContent = { Text("GemmaClaw v1.0.0") },
                leadingContent = { Icon(Icons.Default.Info, null) }
            )
        }
    }
}

@Composable
fun NumberPickerDialog(
    title: String,
    value: Int,
    range: IntRange,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    var current by remember { mutableIntStateOf(value) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text("$current", style = MaterialTheme.typography.headlineSmall)
                Slider(
                    value = current.toFloat(),
                    onValueChange = { current = it.toInt() },
                    valueRange = range.first.toFloat()..range.last.toFloat(),
                    steps = range.count() - 2
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(current); onDismiss() }) {
                Text("OK")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun FloatPickerDialog(
    title: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onDismiss: () -> Unit,
    onConfirm: (Float) -> Unit
) {
    var current by remember { mutableFloatStateOf(value) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text("%.2f".format(current), style = MaterialTheme.typography.headlineSmall)
                Slider(
                    value = current,
                    onValueChange = { current = it },
                    valueRange = range
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(current); onDismiss() }) {
                Text("OK")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
