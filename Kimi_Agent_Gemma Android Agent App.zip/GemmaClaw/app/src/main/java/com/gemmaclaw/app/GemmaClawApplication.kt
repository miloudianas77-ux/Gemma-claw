package com.gemmaclaw.app

import android.app.Application
import androidx.work.Configuration
import com.gemmaclaw.app.memory.AppDatabase
import com.gemmaclaw.app.settings.SettingsRepository

class GemmaClawApplication : Application(), Configuration.Provider {

    val database by lazy { AppDatabase.getDatabase(this) }
    val settingsRepository by lazy { SettingsRepository(this) }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
}
