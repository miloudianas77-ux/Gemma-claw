package com.gemmaclaw.app.skills

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject

class OpenMapSkill : Skill {

    override val name = "open_map"

    override val description = """
Open a location in the maps app.
Args:
{
  "query": "Pizza near me",
  "lat": 37.7749,
  "lng": -122.4194
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult {
        val query = args.optString("query", "")
        val lat = args.optDouble("lat", Double.NaN)
        val lng = args.optDouble("lng", Double.NaN)

        val uri = when {
            !lat.isNaN() && !lng.isNaN() -> {
                Uri.parse("geo:$lat,$lng?q=$lat,$lng")
            }
            query.isNotBlank() -> {
                Uri.parse("geo:0,0?q=${Uri.encode(query)}")
            }
            else -> {
                return SkillResult.failure("Provide query or lat/lng coordinates")
            }
        }

        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            SkillResult.success("Opened map for: ${query.ifBlank { "$lat, $lng" }}")
        } catch (e: Exception) {
            SkillResult.failure("Could not open map: ${e.message}")
        }
    }
}
