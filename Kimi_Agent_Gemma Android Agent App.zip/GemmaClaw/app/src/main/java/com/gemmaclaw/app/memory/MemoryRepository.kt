package com.gemmaclaw.app.memory

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MemoryRepository(
    private val database: AppDatabase
) {
    private val messageDao = database.messageDao()
    private val noteDao = database.noteDao()

    suspend fun saveMessage(content: String, isUser: Boolean) = withContext(Dispatchers.IO) {
        messageDao.insert(MessageEntity(content = content, isUser = isUser))
    }

    suspend fun getChatHistory(limit: Int = 50): List<MessageEntity> = withContext(Dispatchers.IO) {
        messageDao.getRecentMessages(limit).reversed()
    }

    suspend fun clearChatHistory() = withContext(Dispatchers.IO) {
        messageDao.clearAll()
    }

    suspend fun getRecentMemories(limit: Int = 10): List<String> = withContext(Dispatchers.IO) {
        val notes = noteDao.getRecentNotes(limit)
        notes.map { "${it.title}: ${it.content}" }
    }

    suspend fun saveToolResult(toolName: String, result: String) = withContext(Dispatchers.IO) {
        noteDao.insert(
            NoteEntity(
                title = "Tool: $toolName",
                content = result,
                timestamp = System.currentTimeMillis()
            )
        )
    }
}
