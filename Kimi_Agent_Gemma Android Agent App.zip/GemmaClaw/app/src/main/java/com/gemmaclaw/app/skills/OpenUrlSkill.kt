package com.gemmaclaw.app.skills

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject

class OpenUrlSkill : Skill {

    override val name = "open_url"

    override val description = """
Open a URL in the user's browser.
Args:
{
  "url": "https://example.com"
}
    """.trimIndent()

    override suspend fun run(
        context: Context,
        args: JSONObject
    ): SkillResult {
        val url = args.optString("url")

        if (url.isBlank()) {
            return SkillResult.failure("No URL provided")
        }

        val normalizedUrl = when {
            url.startsWith("http://") || url.startsWith("https://") -> url
            url.startsWith("www.") -> "https://$url"
            else -> "https://$url"
        }

        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalizedUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            SkillResult.success("Opened URL: $normalizedUrl")
        } catch (e: Exception) {
            SkillResult.failure("Could not open URL: ${e.message}")
        }
    }
}
