package com.gemmaclaw.app.llm

import android.content.Context
import android.util.Log
import com.gemmaclaw.app.memory.MemoryRepository
import com.gemmaclaw.app.skills.SkillRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import org.json.JSONObject

private const val TAG = "AgentLoop"
private const val MAX_AGENT_STEPS = 3

class AgentLoop(
    private val context: Context,
    private val gemma: GemmaEngine,
    private val skills: SkillRegistry,
    private val memoryRepository: MemoryRepository? = null
) {

    sealed class AgentResponse {
        data class Text(val content: String) : AgentResponse()
        data class Stream(val flow: Flow<String>) : AgentResponse()
        data class Error(val message: String) : AgentResponse()
    }

    suspend fun respond(
        userMessage: String,
        chatHistory: List<PromptBuilder.ChatMessage>,
        useStreaming: Boolean = true
    ): AgentResponse = withContext(Dispatchers.Default) {
        try {
            val memories = memoryRepository?.getRecentMemories(10) ?: emptyList()
            val systemPrompt = PromptBuilder.buildSystemPromptWithMemory(
                skills.manifest(),
                memories
            )

            val historyText = PromptBuilder.formatChatHistory(chatHistory)

            var currentPrompt = PromptBuilder.buildPrompt(
                systemPrompt,
                historyText,
                userMessage
            )

            var steps = 0
            var finalResponse: AgentResponse? = null

            while (steps < MAX_AGENT_STEPS) {
                steps++

                val firstResponse = gemma.generate(currentPrompt)
                Log.d(TAG, "Raw response: $firstResponse")

                val toolCall = parseToolCall(firstResponse)

                if (toolCall == null) {
                    // No tool call — return the response
                    finalResponse = if (useStreaming) {
                        // For streaming UI consistency, re-run as stream
                        val stream = gemma.stream(currentPrompt)
                        AgentResponse.Stream(stream)
                    } else {
                        AgentResponse.Text(firstResponse)
                    }
                    break
                }

                // Tool call detected
                val toolName = toolCall.optString("tool")
                val args = toolCall.optJSONObject("args") ?: JSONObject()

                val skill = skills.get(toolName)
                if (skill == null) {
                    val errorMsg = "I tried to use an unknown skill: $toolName"
                    finalResponse = AgentResponse.Text(errorMsg)
                    break
                }

                // Execute skill
                val result = skill.run(context, args)
                Log.i(TAG, "Skill $toolName result: success=${result.success}, msg=${result.message}")

                // Save to memory if applicable
                if (result.success && result.data != null) {
                    memoryRepository?.saveToolResult(toolName, result.message)
                }

                val toolResultText = """
success=${result.success}
message=${result.message}
data=${result.data ?: "{}"}
                """.trimIndent()

                currentPrompt = PromptBuilder.buildFollowUpPrompt(
                    systemPrompt,
                    historyText,
                    userMessage,
                    firstResponse,
                    toolResultText
                )
            }

            finalResponse ?: AgentResponse.Text("I took too many steps to answer. Please try again.")

        } catch (e: Exception) {
            Log.e(TAG, "Agent loop error: ${e.message}", e)
            AgentResponse.Error("Agent error: ${e.message}")
        }
    }

    suspend fun respondStream(
        userMessage: String,
        chatHistory: List<PromptBuilder.ChatMessage>
    ): Flow<String> = flow {
        // For simplicity, run non-streaming internally then emit result
        // Full streaming with tool calls requires more complex state management
        when (val response = respond(userMessage, chatHistory, useStreaming = false)) {
            is AgentResponse.Text -> emit(response.content)
            is AgentResponse.Error -> emit("Error: ${response.message}")
            is AgentResponse.Stream -> {
                response.flow.collect { emit(it) }
            }
        }
    }

    private fun parseToolCall(text: String): JSONObject? {
        return try {
            val trimmed = text.trim()
            if (!trimmed.startsWith("{")) return null

            val json = JSONObject(trimmed)
            if (!json.has("tool")) return null

            json
        } catch (_: Exception) {
            null
        }
    }
}
