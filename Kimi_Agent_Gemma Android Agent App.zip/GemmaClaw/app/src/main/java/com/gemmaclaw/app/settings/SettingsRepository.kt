package com.gemmaclaw.app.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "gemmaclaw_settings")

class SettingsRepository(private val context: Context) {

    private val dataStore = context.dataStore

    companion object {
        val MODEL_PATH = stringPreferencesKey("model_path")
        val MAX_TOKENS = intPreferencesKey("max_tokens")
        val TEMPERATURE = floatPreferencesKey("temperature")
        val TOP_K = intPreferencesKey("top_k")
        val MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
        val ONBOARDING_COMPLETE = booleanPreferencesKey("onboarding_complete")
    }

    val modelPath: Flow<String> = dataStore.data.map { it[MODEL_PATH] ?: "" }
    val maxTokens: Flow<Int> = dataStore.data.map { it[MAX_TOKENS] ?: 2048 }
    val temperature: Flow<Float> = dataStore.data.map { it[TEMPERATURE] ?: 0.7f }
    val topK: Flow<Int> = dataStore.data.map { it[TOP_K] ?: 40 }
    val memoryEnabled: Flow<Boolean> = dataStore.data.map { it[MEMORY_ENABLED] ?: true }
    val onboardingComplete: Flow<Boolean> = dataStore.data.map { it[ONBOARDING_COMPLETE] ?: false }

    suspend fun setModelPath(path: String) {
        dataStore.edit { it[MODEL_PATH] = path }
    }

    suspend fun setMaxTokens(value: Int) {
        dataStore.edit { it[MAX_TOKENS] = value }
    }

    suspend fun setTemperature(value: Float) {
        dataStore.edit { it[TEMPERATURE] = value }
    }

    suspend fun setTopK(value: Int) {
        dataStore.edit { it[TOP_K] = value }
    }

    suspend fun setMemoryEnabled(enabled: Boolean) {
        dataStore.edit { it[MEMORY_ENABLED] = enabled }
    }

    suspend fun setOnboardingComplete(complete: Boolean) {
        dataStore.edit { it[ONBOARDING_COMPLETE] = complete }
    }
}
