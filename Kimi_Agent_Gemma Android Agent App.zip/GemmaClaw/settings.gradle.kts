rootProject.name = "GemmaClaw"
include(":app")
