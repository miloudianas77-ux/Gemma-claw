# GemmaClaw

**Local Android AI Agent powered by Google Gemma**

GemmaClaw is an offline-first, on-device AI agent for Android that runs Gemma models locally via MediaPipe LLM Inference. It features a chat interface, skill/tool system, local memory, and HyperOS/Xiaomi device optimization.

## Features

- **Local Inference** — Run Gemma models on-device using MediaPipe Tasks GenAI (`.task` / `.litertlm`)
- **Agent Skills** — Structured tool calls for Android actions:
  - Open URLs, share text, launch apps
  - Save/read local notes, set reminders, calendar events
  - Web search (DuckDuckGo), maps, email drafts
  - Text summarize, rewrite, task extraction
- **Local Memory** — Room database for chat history and notes
- **Offline-First** — Works without internet; optional web search when connected
- **HyperOS Optimized** — Battery/background settings guidance for Xiaomi/POCO/Redmi
- **Accessibility Mode** — Optional assistive automation (user-enabled only)

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | Kotlin |
| UI | Jetpack Compose + Material3 |
| LLM Runtime | MediaPipe Tasks GenAI (`com.google.mediapipe:tasks-genai:0.10.27`) |
| Local DB | Room |
| Settings | DataStore Preferences |
| Background | WorkManager + Foreground Service |
| Navigation | Jetpack Navigation Compose |

## Project Structure

```
GemmaClaw/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/gemmaclaw/app/
│       │   ├── GemmaClawApplication.kt
│       │   ├── MainActivity.kt
│       │   ├── llm/
│       │   │   ├── GemmaEngine.kt        # MediaPipe LLM wrapper
│       │   │   ├── PromptBuilder.kt      # System prompts & formatting
│       │   │   └── AgentLoop.kt          # Tool-call loop
│       │   ├── skills/
│       │   │   ├── Skill.kt              # Skill interface
│       │   │   ├── SkillRegistry.kt      # Skill discovery
│       │   │   ├── OpenUrlSkill.kt
│       │   │   ├── ShareTextSkill.kt
│       │   │   ├── AppLauncherSkill.kt
│       │   │   ├── NotesSkill.kt
│       │   │   ├── ReadNotesSkill.kt
│       │   │   ├── ReminderSkill.kt
│       │   │   ├── CalendarEventSkill.kt
│       │   │   ├── OpenMapSkill.kt
│       │   │   ├── WebSearchSkill.kt
│       │   │   ├── SummarizeTextSkill.kt
│       │   │   ├── RewriteTextSkill.kt
│       │   │   ├── ExtractTasksSkill.kt
│       │   │   └── SendEmailDraftSkill.kt
│       │   ├── memory/
│       │   │   ├── AppDatabase.kt
│       │   │   ├── MessageEntity.kt / NoteEntity.kt
│       │   │   ├── MessageDao.kt / NoteDao.kt
│       │   │   └── MemoryRepository.kt
│       │   ├── settings/
│       │   │   └── SettingsRepository.kt # DataStore prefs
│       │   ├── service/
│       │   │   ├── ModelDownloadService.kt
│       │   │   └── GemmaClawAccessibilityService.kt
│       │   ├── receiver/
│       │   │   └── ReminderReceiver.kt
│       │   └── ui/
│       │       ├── theme/
│       │       ├── ChatScreen.kt
│       │       ├── SettingsScreen.kt
│       │       ├── ModelPickerScreen.kt
│       │       ├── HyperOSScreen.kt
│       │       └── viewmodel/
│       │           ├── ChatViewModel.kt
│       │           └── SettingsViewModel.kt
│       └── res/values/
├── build.gradle.kts
├── settings.gradle.kts
└── gradle/wrapper/
```

## Build Instructions

### Prerequisites

- Android Studio Ladybug (2024.2.1) or newer
- JDK 17
- Android SDK 36
- A physical Android device (recommended for MediaPipe LLM Inference)

### Clone & Build

```bash
git clone <your-repo> GemmaClaw
cd GemmaClaw
./gradlew assembleDebug
```

APK output:
```
app/build/outputs/apk/debug/app-debug.apk
```

Install via adb:
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Model Setup

GemmaClaw requires a MediaPipe-compatible model file (`.task` or `.litertlm`).

### Option 1: Import via App
1. Launch GemmaClaw
2. Go to **Settings → Models**
3. Tap **Import Model** and select your `.task` file

### Option 2: Push via ADB
```bash
adb shell mkdir -p /data/local/tmp/llm/
adb push gemma.task /data/local/tmp/llm/gemma.task
```

Then set the model path in-app or update `SettingsRepository` defaults.

### Where to Get Models

- Convert Gemma using [MediaPipe model conversion tools](https://ai.google.dev/edge/mediapipe/solutions/genai/llm_inference)
- Use pre-converted `.task` models from the [Google AI Edge Gallery](https://github.com/google-ai-edge/gallery) project
- Models are typically 2-4GB; ensure your device has sufficient RAM and storage

## HyperOS / Xiaomi Optimization

For HyperOS 3+ devices (Xiaomi, POCO, Redmi), configure these manually:

| Setting | Path |
|---------|------|
| No Battery Restrictions | Settings → Apps → GemmaClaw → Battery Saver → No restrictions |
| Autostart | Settings → Apps → Permissions → Autostart → GemmaClaw |
| Lock in Recents | Recents → Long press GemmaClaw → Lock |
| Notifications | Settings → Apps → GemmaClaw → Notifications → Allow |
| Exact Alarms | Settings → Apps → GemmaClaw → Alarms & reminders → Allow |

The app includes a **HyperOS Optimization** screen with shortcuts to these settings.

## Skill System

When the AI needs to act, it outputs structured JSON:

```json
{
  "tool": "open_url",
  "args": {
    "url": "https://youtube.com/results?search_query=Gemma+AI"
  }
}
```

The app parses this, executes the skill, and returns the result to the model for a natural-language follow-up.

**Security rules:**
- Skills never silently control other apps
- Messaging requires the Android share sheet (user confirmation)
- Accessibility automation is opt-in only and transparent

## Architecture Notes

- **AgentLoop** limits tool recursion to `MAX_AGENT_STEPS = 3`
- **GemmaEngine** wraps MediaPipe `LlmInference` with coroutine-friendly APIs
- **MemoryRepository** persists chat history only when `memoryEnabled = true`
- **PromptBuilder** injects tool manifests and memories into the system prompt

## License

Apache 2.0 — See LICENSE file

## Acknowledgements

- [Google Gemma](https://ai.google.dev/gemma)
- [MediaPipe LLM Inference](https://ai.google.dev/edge/mediapipe/solutions/genai/llm_inference)
- [Google AI Edge Gallery](https://github.com/google-ai-edge/gallery) (reference implementation)
